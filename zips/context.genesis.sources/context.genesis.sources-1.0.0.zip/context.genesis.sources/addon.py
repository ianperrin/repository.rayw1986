# -*- coding: utf-8 -*-		
		
import xbmc		

if __name__ == '__main__':		
	xbmc.executebuiltin('XBMC.RunAddon(plugin.video.genesis,action=cache_clear_src)')