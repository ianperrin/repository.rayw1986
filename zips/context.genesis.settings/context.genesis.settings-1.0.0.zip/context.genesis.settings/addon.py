# -*- coding: utf-8 -*-		
		
import xbmc		

if __name__ == '__main__':		
	xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.genesis/?action=settings_playback")')